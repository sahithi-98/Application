package com.cg.test;



import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.trainapp.bean.TrainBean;
import com.cg.trainapp.dao.TrainDaoImpl;
import com.cg.trainapp.exception.TrainException;




public class TrainDaoTest{

	static TrainDaoImpl dao;
	static TrainBean train;

	@BeforeClass
	public static void initialize() {
		//System.out.println("in before class");
		dao = new TrainDaoImpl();
		train = new TrainBean();
	}

	@Test
	public void testingBeanDetails() throws TrainException {
		assertNotNull(dao.addPassengerDetails(train));
	}
	
	@Test
	public void testPassengerDetails() throws TrainException {

		train.setPassengerName("PeterParker");
		train.setPhoneNumber("9843376855");
		train.setAddress("Koyambedu");
		train.setDestination("Coimbatore");
		
	}
	
	@Test
	public void testTicketId() throws TrainException {
		assertNotNull(dao.viewBookingDetails("1002"));
		assertTrue("Valid ticketID",
		Integer.parseInt(dao.addPassengerDetails(train)) > 1000);
	}
	
	@Test
	public void testIDwithPassenger() throws TrainException {
		assertEquals("mama", dao.viewBookingDetails("1002").getPassengerName());
	}
	

}