package com.cg.trainapp.bean;

import java.util.Date;

public class TrainBean {
	private String ticketId;
	private String passengerName;
	private String phoneNumber;
	private String address;
	private String destination;
	private Date bookingDate;
	private double ticketPrice;
	
	
	
	public String getTicketId() {
		return ticketId;
	}
	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}
	public String getPassengerName() {
		return passengerName;
	}
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Date getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}
	public double getTicketPrice() {
		return ticketPrice;
	}
	public void setTicketPrice(double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}
	@Override
	public String toString() {
		return "BoOkIngS Details \nTicketId=" + ticketId + "\n PassengerName=" + passengerName + "\n PhoneNumber=" + phoneNumber
				+ "\n Address=" + address + "\n Destination=" + destination + ", BookingDate=" + bookingDate
				+ "\n TicketPrice=" + ticketPrice + "";
	}
	
	
	
}
