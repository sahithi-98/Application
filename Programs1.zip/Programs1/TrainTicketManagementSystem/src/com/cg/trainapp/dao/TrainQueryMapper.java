package com.cg.trainapp.dao;

public interface TrainQueryMapper {

	public static final String RETRIVE_ALL_QUERY="SELECT ticketId,passengerName,address,phoneNumber,bookingDate,destination,ticketPrice FROM train_details";
	public static final String VIEW_BOOKING_DETAILS_QUERY="SELECT passengerName,address,phoneNumber,bookingDate,destination,ticketprice FROM train_details WHERE  ticketID=?";
	public static final String INSERT_QUERY="INSERT INTO train_details VALUES(ticketId_sequence.NEXTVAL,?,?,?,?,SYSDATE,?)";
	public static final String TICKETID_QUERY_SEQUENCE="SELECT ticketId_sequence.CURRVAL FROM DUAL";
	
	
}
