package com.cg.dao;

import java.util.List;

import com.cg.PatientException.PatientException;
import com.cg.bean.PatientBean;

public interface IpatientDAO
{
	public String addPatientDetails(PatientBean pb) throws PatientException;
	public PatientBean viewPatientDetails(String Patient_id)throws PatientException;
	public List<PatientBean> retriveAllDetails()throws PatientException;
}
