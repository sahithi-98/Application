package com.cg.dao;

public interface QueryMapper 
{
	public static final String RETRIVE_ALL_QUERY="SELECT patient_name,phone,description,age,date1 FROM patient_detail";
	public static final String VIEW_PATIENT_DETAILS_QUERY="SELECT patient_name,phone,description,age FROM patient_detail WHERE  patient_id=?";
	public static final String INSERT_QUERY="INSERT INTO patient_detail VALUES(patient_id_sequence1.NEXTVAL,?,?,?,?,sysdate)";
	public static final String PATIENTID_QUERY_SEQUENCE="SELECT patient_Id_sequence1.CURRVAL FROM DUAL";
	
}
