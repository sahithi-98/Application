package com.cg.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.cg.PatientException.PatientException;
import com.cg.bean.PatientBean;
import com.cg.dao.PatientDAO;
import com.cg.service.IPatientservice;
import com.cg.service.PatientService;

public class PatientMain 
{
	static Scanner sc=new Scanner(System.in);
	static IPatientservice ipatientService = null;
	static PatientService patientservice=null;
	static String patient_id = null;
	static Logger logger = Logger.getRootLogger();
	public static void main(String[] args)
	{
		PropertyConfigurator.configure("resources//log4j.properties");
	
		PatientBean patientbean=null;
		int option = 0;
		while (true)
		{
			System.out.println("1.Add Patient Details ");
			System.out.println("2.Search Patient Details");
			System.out.println("3.Retrive All");
			System.out.println("4.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			
			try {
				option = sc.nextInt();
				switch (option) 
				{
				case 1:
					while(patientbean==null)
					{
						patientbean = populatePatientBean();
					}
					try
					{
						
						ipatientService = new  PatientService();
						 patient_id = ipatientService.addPatientDetails(patientbean);
						
							System.out.println("Patient details  has been successfully registered ");
							System.out.println("Donator  ID Is: " + patient_id);
						
					}
					catch (PatientException PatientException) 
					{
						logger.error("exception occured", PatientException);
						System.err.println("ERROR : "+ PatientException.getMessage());
					}
					finally {
						patient_id = null;
						ipatientService = null;
						patientbean = null;
					}
					break;
					
				case 2:
					patientservice =new PatientService();
					
					System.out.println("Enter numeric patient id:");
					patient_id = sc.next();
					
					while(true)
					{
						if (patientservice.validatePatientId(patient_id)) {
							break;
						} else {
							System.err
									.println("Please enter numeric patient id only, try again");
							patient_id = sc.next();
						}
					}
					patientbean=getPatientDetails(patient_id);
					
					if(patientbean != null)
					{
						System.out.println("Name             :"
								+ patientbean.getPatient_name());
						
						System.out.println("Phone Number     :"
								+ patientbean.getPhone());
						
						System.out.println("Description         :"
								+ patientbean.getDescription());
						
						System.out.println("Age    :"
								+ patientbean.getAge());
						
						System.out.println("Date    :"
								+ LocalDate.now());
						
					}
					else {
						System.err
								.println("There are no patient details associated with donor id "
										+ patient_id);
					}
					break;
					
				case 3:
					ipatientService = new PatientService();
					try {
						List<PatientBean> patientList = new ArrayList<PatientBean>();
						patientList = ipatientService.retriveAllDetails();
						
						if(patientList != null)
						{
							Iterator<PatientBean> i = patientList.iterator();
							while (i.hasNext()) {
								System.out.println(i.next());
						}
					} else
					{
						System.out
						.println("Nobody has made a patient details, yet.");
					}
					}
					catch (PatientException e) {

						System.out.println("Error  :" + e.getMessage());
					}


					break;
					
				case 4:

					System.out.print("Exit Patient Application");
					System.exit(0);
					break;
					
				default:
					System.out.println("Enter a valid option[1-4]");
					}//end of switch
				}

		
			catch (InputMismatchException e) 
			{
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
	         }
		}//end of while

}
		

		/*
		 * This function will call the service layer method and return the bean
		 * object which is populated by the information of the given donorId in
		 * parameter
		 */
		private static PatientBean getPatientDetails(String patient_id) {
			PatientBean PatientBean = null;
			ipatientService = new PatientService();

			try {
				PatientBean = ipatientService.viewPatientDetails(patient_id);
			} catch (PatientException PatientException) {
				logger.error("exception occured ", PatientException);
				System.out.println("ERROR : " + PatientException.getMessage());
			}

			ipatientService = null;
			return PatientBean;
		}

		private static PatientBean populatePatientBean() 
	{
		PatientBean patientbean= new PatientBean();
		System.out.println("\n Enter Details");
		
		System.out.println("Enter Patient name: ");
		patientbean.setPatient_name(sc.next());
		
		System.out.println("Enter Patient contact: ");
		String str=sc.next();
		//int ph=Integer.parseInt(str);
		patientbean.setPhone(str);
		
		System.out.println("Enter Patient Description: ");
		patientbean.setDescription(sc.next());

		System.out.println("Enter Patient Age: ");
		patientbean. setAge(sc.nextInt());
		
		patientservice = new PatientService();
		
		try {
			patientservice.validatePatient(patientbean);
			return patientbean;
		} catch (PatientException PatientException) {
			logger.error("exception occured", PatientException);
			System.err.println("Invalid data:");
			System.err.println(PatientException.getMessage() + " \n Try again..");
			System.exit(0);

		}
	
		// TODO Auto-generated method stub
		return null;
	}
}

