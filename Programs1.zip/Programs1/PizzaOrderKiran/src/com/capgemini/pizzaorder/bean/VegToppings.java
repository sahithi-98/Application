package com.capgemini.pizzaorder.bean;

public enum VegToppings {
	CAPSICUM,MUSHROOM,JALAPENO,PANEER;

};
