package com.capgemini.pizzaorder.dao;

public interface IPizzaServiceDAO {

}
