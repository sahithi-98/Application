package com.capgemini.pizzaorder.ui;

import java.sql.Connection;
import java.sql.DriverManager;

public class CommConnection {
	static Connection c=null;
	public static  Connection getCon()
	{
			try
			{
				Class.forName("oracle.jdbc.OracleDriver");
				c=(Connection) DriverManager.getConnection("jdbc:oracle:thin:"+"@10.219.34.3:1521:orcl","trg625","training625");
				System.out.println("connected");
			}catch(Exception e)
			{
				System.out.println(e);	
			}
		return c;

	}
}
