package bean;

public class LoginBean {
private String mailid,password;

public String getMailid() {
	return mailid;
}

public void setMailid(String mailid) {
	this.mailid = mailid;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}


}
