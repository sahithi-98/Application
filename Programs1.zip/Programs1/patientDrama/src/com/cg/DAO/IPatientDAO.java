package com.cg.DAO;

import com.cg.bean.PatientBean;

public interface IPatientDAO {
	
	void getPatientDetails(int id) throws Exception;
	void addPatientDetails(PatientBean bean) throws Exception;

}
