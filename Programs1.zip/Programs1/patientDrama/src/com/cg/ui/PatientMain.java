package com.cg.ui;

import java.util.Scanner;

import com.cg.bean.PatientBean;
import com.cg.service.PatientService;

public class PatientMain {
	
	static Scanner sc=new Scanner(System.in);
	
	
	public static void main(String args[]) throws Exception
	{   
		String name;
		String description;
		int age;
		
		PatientBean bean=new PatientBean();
		PatientService service=new PatientService();
		
		System.out.println("1.Insert the details\n 2.View The details\n 3.Exit");
		
		int option=sc.nextInt();
		
		switch(option)
		{
	  case 1:
		  System.out.println("Enter the Name");
		  name=sc.next();
		  bean.setPatient_name(name);
		  System.out.println("Enter the age");
		  age=sc.nextInt();
		  bean.setAge(age);
		  System.out.println("Enter the  description");
		  description=sc.next();
		  bean.setDescription(description);
		  service.addPatientDetails(bean); 
		  break;
	  case 2:
		  System.out.println("Enter thje userId");
		  int id=sc.nextInt();
		  service.getPatientDetails(id);
		  
		  break;
	  case 3:break;
		default:System.out.println("Enter the valid option");
		
		
		}
		
	}

}
