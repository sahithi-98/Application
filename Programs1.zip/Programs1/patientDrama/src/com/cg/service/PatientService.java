package com.cg.service;

import com.cg.DAO.PatientDAO;
import com.cg.bean.PatientBean;

public class PatientService implements IPatientService{

	@Override
	public void addPatientDetails(PatientBean bean) throws Exception {
		// TODO Auto-generated method stub
		PatientService pserv=new PatientService();
		PatientDAO pdao=new PatientDAO();
		pdao.addPatientDetails(bean);
		
	}

	@Override
	public void getPatientDetails(int id) throws Exception {
		// TODO Auto-generated method stub
		PatientDAO pdao=new PatientDAO();
		pdao.getPatientDetails(id);
	}

}
