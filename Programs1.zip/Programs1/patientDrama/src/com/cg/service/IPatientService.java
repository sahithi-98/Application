package com.cg.service;

import com.cg.bean.PatientBean;

public interface IPatientService {
	

	void getPatientDetails(int id)throws Exception;
	void addPatientDetails(PatientBean bean) throws Exception;
	

}
