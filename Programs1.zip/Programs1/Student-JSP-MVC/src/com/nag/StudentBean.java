package com.nag;

import java.io.Serializable;

public class StudentBean implements Serializable
{
  private String student_name;
  private String address;
  private String city;
  private int cs_marks;
  private int physics_marks;
  private int total;
public String getStudent_name() {
	return student_name;
}
public String getAddress() {
	return address;
}
public String getCity() {
	return city;
}
public int getCs_marks() {
	return cs_marks;
}
public int getPhysics_marks() {
	return physics_marks;
}
public int getTotal() {
	return total;
}
public void setStudent_name(String student_name) {
	this.student_name = student_name;
}
public void setAddress(String address) {
	this.address = address;
}
public void setCity(String city) {
	this.city = city;
}
public void setCs_marks(int cs_marks) {
	this.cs_marks = cs_marks;
}
public void setPhysics_marks(int physics_marks) {
	this.physics_marks = physics_marks;
}
public void setTotal(int total) {
	this.total = total;
}
  

  
}